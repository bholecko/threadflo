<?php

class Peakk_Threadflo_Model_Mysql4_Item_Image extends Peakk_Threadflo_Model_Resource_Item_Image
{

}