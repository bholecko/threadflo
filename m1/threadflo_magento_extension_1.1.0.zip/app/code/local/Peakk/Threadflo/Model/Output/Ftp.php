<?php

class Peakk_Threadflo_Model_Output_Ftp extends Varien_Object
{

    const FTP_DEFAULT_PROTOCOL = 'ftp://';
    const FTP_DEFAULT_PORT = 21;

    private $host = '';
    private $user = '';
    private $pass = '';
    private $protocol = '';
    private $connection = null;

    function __construct()
    {
        parent::__construct();

        $this->host = Mage::helper('threadflo')->getFtpHost();
        $this->port = Mage::helper('threadflo')->getFtpPort();
        $this->user = Mage::helper('threadflo')->getFtpUsername();
        $this->pass = Mage::helper('threadflo')->getFtpPassword();
        $this->protocol = Mage::helper('threadflo')->getFtpProtocol();
    }

    public function connect()
    {
        $helper = Mage::helper('threadflo');

        if ($this->host) {
            try{
                $ftp = new Varien_Io_Ftp();

                $ftp->open(array(
                    'user' => $this->user,
                    'password' => $this->pass,
                    'host' => $this->host,
                    'port' => $this->port ? $this->port : self::FTP_DEFAULT_PORT,
                    'ssl' => $this->protocol == 'sftp' || $this->protocol == 'ftps'
                ));

                $this->connection = $ftp;

                return true;
            } catch (Exception $e) {
                $helper->logError('FTP Error: '.$e);
            }
        } else {
            $helper->logError('FTP Error: FTP host not configured.');
        }

        return false;
    }

    public function put($fileName, $file)
    {
        $helper = Mage::helper('threadflo');

        if ($this->connection) {
            try {
                $remotePath = Mage::helper('threadflo')->getFtpRemotePath();

                if ($remotePath) {
                    $this->connection->mkdir($remotePath);

                    $this->connection->write($remotePath.'/'.$fileName, $file);
                } else {
                    $this->connection->write($fileName, $file);
                }

                return true;
            } catch (Exception $e) {
                $helper->logError('FTP Error: '.$e);
            }
        }

        return false;
    }
    
    public function disconnect()
    {
        if ($this->connection) {
            try {
                $this->connection->close();

                return true;
            } catch (Exception $e) {
                $helper->logError('FTP Error: '.$e);
            }
        }

        return false;
    }

}