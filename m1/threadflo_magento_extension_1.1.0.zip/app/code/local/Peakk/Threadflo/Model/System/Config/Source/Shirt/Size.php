<?php

class Peakk_Threadflo_Model_System_Config_Source_Shirt_Size
{

    protected $_options;

    public function toAttributeArray()
    {
        if (!$this->_options) {
            $options = array (
                0 => 'X-Small',
                1 => 'Small',
                2 => 'Medium',
                3 => 'Large',
                4 => 'X-Large',
                5 => '2X-Large',
                6 => '3X-Large',
                7 => '4X-Large',
                8 => '5X-Large',
                9 => '6X-Large'
            );

            $this->_options = $options;
        }

        return $this->_options;
    }

}