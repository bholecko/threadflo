<?php

class Peakk_Threadflo_Model_System_Config_Source_OrderField
{
    
    protected $_options;

    public function toOptionArray()
    {
        if (!$this->_options) {
            $options = array();
            $orderTableName = Mage::getSingleton('core/resource')->getTableName('sales/order');
            $orderColumns = Mage::getSingleton('core/resource')->getConnection('core_read')->describeTable($orderTableName);

            if ($orderColumns) {
                foreach ($orderColumns as $orderColumn) {
                    $orderColumnName = $orderColumn['COLUMN_NAME'];

                    $options[] = array(
                        'value' => $orderColumnName,
                        'label' => $orderColumnName
                    );
                }
            }

            $this->_options = $options;
        }

        return $this->_options;
    }

}