<?php

class Peakk_Threadflo_Model_Api extends Mage_Core_Model_Abstract
{

    const API_CONNECTOR_URL = 'https://login.threadflo.com/api/connector/';
    const API_ORDERS_URI = 'orders';
    const API_ORDER_URI = 'order';
    const API_PRODUCTS_URI = 'products';
    const API_PRODUCT_URI = 'product';
    const API_CONTENT_TYPE = 'application/json';

    private function getOrdersApiUrl()
    {
        return self::API_CONNECTOR_URL.self::API_ORDERS_URI;
    }

    private function getOrderApiUrl()
    {
        return self::API_CONNECTOR_URL.self::API_ORDER_URI;
    }

    private function getProductsApiUrl()
    {
        return self::API_CONNECTOR_URL.self::API_PRODUCTS_URI;
    }

    private function getProductApiUrl($threadfloProductId)
    {
        return self::API_CONNECTOR_URL.self::API_PRODUCT_URI.'/'.$threadfloProductId;
    }

    private function send($apiUrl, $request = null)
    {
        $helper = Mage::helper('threadflo');

        if (!$helper->isApiEnabled()) {
            $helper->log('API Request Error: API disabled.');
            $helper->logError('API Request Error: API disabled.');

            return false;
        } elseif ($helper->isApiConfigured()) {
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:'.self::API_CONTENT_TYPE, 'X-API-KEY:'.$helper->getApiKey()));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            if ($request) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
            }

            if (curl_errno($ch)) {
                $helper->logError('System Error: curl init error.');
            }

            $response = curl_exec($ch);

            curl_close($ch);

            $responseXml = simplexml_load_string($response);

            if ($response) {
                if ($responseXml->error) {
                    $helper->logError('API Response Error: '.$responseXml->error);
                } else {
                    return $responseXml;
                }
            } else {
                $helper->logError('API Response Error: API connection failed.');
            }
        } else {
            $helper->logError('API Error: API not configured.');
        }

        return false;
    }

    public function importItems()
    {
        $helper = Mage::helper('threadflo');
        $items = $this->send($this->getProductsApiUrl());

        if (isset($items) && $items instanceof SimpleXMLElement) {
            foreach ($items->item->item as $item) {
                $threadfloItemId = (int)$item->id;
                $itemName = (string)$item->name;
                $parentSku = (string)$item->parent_sku;

                $threadfloProduct = $this->send($this->getProductApiUrl($threadfloItemId));

                if (!$threadfloProduct) {
                    $helper->logError('API Error: Product with Threadflo Item ID '.$threadfloItemId.' not returned.');

                    return false;
                }
                
                foreach ($threadfloProduct->item_variants->item_variant as $threadfloItem) {
                    $sku = (string)$threadfloItem->sku;
                    $colorName = (string)$threadfloItem->color_name;
                    $sizeName = (string)$threadfloItem->size_name;
                    $price = (double)$threadfloProduct->unit_price;

                    $threadfloItemModel = Mage::getModel('threadflo/item')->loadBySku($sku);

                    $newItemData = array(
                        'entity_id' => $threadfloItemModel->getEntityId() ? $threadfloItemModel->getEntityId() : null,
                        'threadflo_item_id' => $threadfloItemId,
                        'item_name' => $itemName,
                        'parent_sku' => $parentSku,
                        'sku' => $sku,
                        'color_name' => $colorName,
                        'size_name' => $sizeName,
                        'price' => $price
                    );

                    $threadfloItemModel->setData($newItemData)->save();

                    $threadfloItemModel->deleteImages();

                    foreach ($threadfloProduct->item_images->item_image as $threadfloItemImage) {
                        $imageName = (string)$threadfloItemImage->name;
                        $imageUrl = (string)$threadfloItemImage->url;

                        $threadfloItemImageModel = Mage::getModel('threadflo/item_image');

                        $newItemImageData = array(
                            'threadflo_item_entity_id' => $threadfloItemModel->getId(),
                            'name' => $imageName,
                            'url' => $imageUrl
                        );

                        $threadfloItemImageModel->setData($newItemImageData)->save();
                    }
                }
            }

            return true;
        }

        return false;
    }

    public function order($order)
    {
        $helper = Mage::helper('threadflo');

        $orderLines = array();

        foreach ($order->getItemsCollection() as $orderItem) {
            $orderLines[] = array(
                'sku' => (string)$orderItem->getThreadfloItemSku(),
                'qty' => (int)$orderItem->getQtyOrdered(),
                'price' => round($orderItem->getPrice(), 2)
            );
        }

        $region = Mage::getModel('directory/region')->load($order->getShippingAddress()->getRegionId());

        // TODO add created date
        $orderData = array(
            'member_ref_no' => $helper->getMemberRefNo(),
            'cust_first_name' => $order->getShippingAddress()->getFirstname(),
            'cust_last_name' => $order->getShippingAddress()->getLastname(),
            'cust_address_1' => $order->getShippingAddress()->getStreet1(),
            'cust_address_2' => $order->getShippingAddress()->getStreet2(),
            'cust_city' => $order->getShippingAddress()->getCity(),
            'cust_state' => $region->getCode(),
            'cust_zipcode' => $order->getShippingAddress()->getPostcode(),
            'cust_country' => $order->getShippingAddress()->getCountry(),
            'platform_id' => $helper->getPlatformId(),
            'domain' => Mage::getUrl(),
            'order_lines' => array(
                'order_line' => $orderLines
            )
        );

        $response = $this->send($this->getOrderApiUrl(), json_encode($orderData));

        if ($response) {
            return true;
        } else {
            return false;
        }
    }

    public function importOrderStatus()
    {
        $orders = $this->send($this->getOrdersApiUrl());

        if (isset($orders) && $orders instanceof SimpleXMLElement) {
            foreach ($orders->item->item as $order) {
                $orderId = $order->threadflo_order_id;
                $orderStatus = $order->order_status;
                $orderObj = Mage::getModel('sales/order')->loadByAttribute('threadflo_order_id', $orderId);

                // TODO: Status logic update
                if ($orderStatus == 'Shipped' && $orderObj->getStatus() != 'complete') {
                    $orderObj->setStatus('complete');
                    $orderObj->addStatusHistoryComment('Threadflo order shipped.');

                    $orderObj->save();
                }
            }
        }
    }

}