<?php

class Peakk_Threadflo_Model_Processor
{

    public function updateThreadfloItem($productIds, $threadfloItemId, $threadfloItemSku)
    {
        if ($productIds && $threadfloItemId && $threadfloItemSku) {
            if (!is_array($productIds)) {
                $productIds = explode(',', $productIds);
            }

            $threadfloItemSizeAttribute = Mage::getModel('eav/entity_attribute')->loadByCode(Mage_Catalog_Model_Product::ENTITY, 'threadflo_item_size');
            $threadfloItemColorAttribute = Mage::getModel('eav/entity_attribute')->loadByCode(Mage_Catalog_Model_Product::ENTITY, 'threadflo_item_color');

            foreach ($productIds as $productId) {
                $product = Mage::getModel('catalog/product')->load(intVal($productId));

                if ($product && $product->getId()) {
                    $item = Mage::getModel('threadflo/item')->loadBySku($threadfloItemSku);

                    if ($item && $item->getEntityId()) {
                        $itemSizeName = $item->getSizeName();
                        $itemSizeCode = '';
                        $itemColorName = $item->getColorName();
                        $itemColorCode = '';
                        $threadfloItemSizeAttributeOptions = Mage::getModel('eav/entity_attribute_option')->getCollection()
                                ->setStoreFilter()
                                ->setAttributeFilter($threadfloItemSizeAttribute->getAttributeId())
                                ->load()
                                ->toOptionArray();
                        $threadfloItemColorAttributeOptions = Mage::getModel('eav/entity_attribute_option')->getCollection()
                                ->setStoreFilter()
                                ->setAttributeFilter($threadfloItemColorAttribute->getAttributeId())
                                ->load()
                                ->toOptionArray();

                        foreach ($threadfloItemSizeAttributeOptions as $threadfloItemSizeAttributeOption) {
                            if ($threadfloItemSizeAttributeOption['label'] == $itemSizeName) {
                                $itemSizeCode = $threadfloItemSizeAttributeOption['value'];
                            }
                        }

                        foreach ($threadfloItemColorAttributeOptions as $threadfloItemColorAttributeOption) {
                            if ($threadfloItemColorAttributeOption['label'] == $itemColorName) {
                                $itemColorCode = $threadfloItemColorAttributeOption['value'];
                            }
                        }

                        $product->setThreadfloItemId($item->getThreadfloItemId());
                        $product->setThreadfloItemSku($item->getSku());
                        $product->setThreadfloItemSize($itemSizeCode);
                        $product->setThreadfloItemColor($itemColorCode);

                        $product->save();
                    }
                }
            }

            return true;
        }elseif (!$productIds) {
            $item = Mage::getModel('threadflo/item')->loadByItemId($threadfloItemId);

            if ($item && $item->getEntityId()) {
                $productsWithItemId = Mage::getModel('catalog/product')->getCollection()
                    ->addAttributeToFilter('threadflo_item_id', $item->getThreadfloItemId())
                    ->load();

                if ($productsWithItemId) {
                    foreach ($productsWithItemId as $productWithItemId) {
                        $productWithItemId->setThreadfloItemId('');
                        $productWithItemId->setThreadfloItemSku('');
                        $productWithItemId->setThreadfloItemSize('');
                        $productWithItemId->setThreadfloItemColor('');

                        $productWithItemId->save();
                    }
                }
            }

            return true;
        }

        return false;
    }
    
    public function processNewItemOrders($itemOrderIds)
    {
        $helper = Mage::helper('threadflo');

        if ($itemOrderIds) {
            if ($helper->isApiEnabled()) {
                $api = Mage::getModel('threadflo/api');

                foreach ($itemOrderIds as $itemOrderId) {
                    $order = Mage::getModel('sales/order')->load($itemOrderId);

                    $api->order($order);
                }
            }

            if ($helper->isExportEnabled()) {
                $tsv = Mage::getModel('threadflo/output_tsv');
                $orders = array();

                foreach ($itemOrderIds as $itemOrderId) {
                    $order = Mage::getModel('sales/order')->load($itemOrderId);

                    if ($order) {
                        $orders[] = $order;
                    }
                }

                // Create and export TSV file to file system
                $exportFileName = $tsv->export($orders);

                // E-mail resulting file if enabled
                if (Mage::helper('threadflo')->isEmailExportEnabled()) {
                    $email = Mage::getModel('threadflo/output_email');

                    $email->send($exportFileName, $tsv);
                }

                // FTP resulting file if enabled
                if (Mage::helper('threadflo')->isFtpExportEnabled()) {
                    $ftp = Mage::getModel('threadflo/output_ftp');
                    $isConnected = $ftp->connect();

                    if ($isConnected) {
                        $ftp->put($exportFileName, $tsv);

                        $ftp->disconnect();
                    } else {
                        $helper->logError('FTP Error: FTP connection failed.');
                    }
                }
            }
        }
    }

}