<?php

class Peakk_Threadflo_Model_Observer
{

    // sales_quote_item_set_product
    public function salesQuoteItemSetThreadfloItemId($observer)
    {
        $quoteItem = $observer->getEvent()->getQuoteItem();
        $product = $observer->getEvent()->getProduct();

        $quoteItem->setThreadfloItemId((int)$product->getThreadfloItemId());
        $quoteItem->setThreadfloItemSku((string)$product->getThreadfloItemSku());
    }

    public function checkNewOrders($observer)
    {
        $helper = Mage::helper('threadflo');

        if (Mage::helper('threadflo')->isExportEnabled()) {
            $orderIds = Mage::helper('threadflo')->getTodaysOrderItems();

            if ($orderIds) {
                Mage::getModel('threadflo/processor')->processNewItemOrders($orderIds);
            } else {
                $helper->log('Threadflo has no orders to process today.');
            }
        }
    }

}