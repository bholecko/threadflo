<?php

class Peakk_Threadflo_Model_Output_Tsv extends Varien_Object
{

    const TAB = "\t";
    const NEWLINE = "\n";
    const COMPANY_ID_HEADER = 'company_id';

    public function export($orders)
    {
        $tsv = $this->ordersToTsv($orders);
        $exportFilePath = Mage::helper('threadflo')->getExportFilePath();
        $exportFileName = Mage::helper('threadflo')->generateUniqueFilename();
        $file = fopen($exportFilePath.$exportFileName, 'w');

        fwrite($file, $tsv);
        fclose($file);

        return $exportFileName;
    }
    
    private function ordersToTsv($orders)
    {
        $orderAttributes = Mage::helper('threadflo')->getOrderAttributes();
        $tsv = '';

        if ($orders && $orderAttributes) {
            $tsv .= self::COMPANY_ID_HEADER.self::TAB;

            foreach ($orderAttributes as $orderAttribute) {
                $tsv .= $orderAttribute.self::TAB;
            }

            $tsv = Mage::helper('threadflo')->strReplaceLast(self::TAB, self::NEWLINE, $tsv);

            foreach ($orders as $order) {
                $tsv .= Mage::helper('threadflo')->getCompanyId().self::TAB;

                foreach ($orderAttributes as $orderAttribute) {
                    $orderFieldValue = $order->getData($orderAttribute);

                    if ($orderFieldValue === true) {
                        $orderFieldValue = 1;
                    } else if ($orderFieldValue === false) {
                        $orderFieldValue = 0;
                    }

                    if ($orderAttribute == Peakk_Threadflo_Helper_Data::DEFAULT_ORDER_EXPORT_FIELD_ID) {
                        $tsv .= Mage::helper('threadflo')->getOrderNumberPrefix();
                    }

                    $tsv .= ($orderFieldValue ? $orderFieldValue : ' ').self::TAB;
                }

                $tsv = Mage::helper('threadflo')->strReplaceLast(self::TAB, self::NEWLINE, $tsv);
            }
        }

        return $tsv;
    }

}