<?php

class Peakk_Threadflo_Model_System_Config_Source_Ftp_Protocol
{

    protected $_options;
    
    public function toOptionArray()
    {
        if (!$this->_options) {
            $options = array();

            $options[] = array(
                'value' => 'ftp',
                'label' => 'FTP'
            );

            $options[] = array(
                'value' => 'ftps',
                'label' => 'FTPS'
            );

            $this->_options = $options;
        }

        return $this->_options;
    }

}