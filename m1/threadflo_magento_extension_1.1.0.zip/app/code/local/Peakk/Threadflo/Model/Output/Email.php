<?php

class Peakk_Threadflo_Model_Output_Email extends Varien_Object
{

    const OUTPUT_TYPE_EMAIL_SUBJECT = 'Threadflo Orders for Today';
    const OUTPUT_TYPE_EMAIL_BODY = 'Threadflo orders file attached.';
    const TXT_MIME_TYPE = 'txt';
    
    public function send($fileName, $content)
    {
        $exportEmailAddress = Mage::helper('threadflo')->getExportFileEmail();
        $exportEmailAddressOfSender = Mage::helper('threadflo')->getExportFileEmailOfSender();

        $attachment = new Zend_Mime_Part($content);
        $attachment->type = self::TXT_MIME_TYPE;
        $attachment->disposition = Zend_Mime::DISPOSITION_INLINE;
        $attachment->encoding = Zend_Mime::ENCODING_BASE64;
        $attachment->filename = $fileName;

        $mail = new Zend_Mail();
        $mail->setBodyText(self::OUTPUT_TYPE_EMAIL_BODY);
        $mail->addTo($exportEmailAddress, $exportEmailAddress);
        $mail->setFrom($exportEmailAddressOfSender, $exportEmailAddressOfSender);
        $mail->setSubject(self::OUTPUT_TYPE_EMAIL_SUBJECT);
        $mail->addAttachment($attachment);
        $mail->send();
    }

}