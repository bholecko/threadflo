<?php

class Peakk_Threadflo_Model_Item extends Mage_Core_Model_Abstract
{

    const THREADFLO_IMAGE_DIR = 'graphic-server/storage/orders/';
    const THREADFLO_IMAGE_SERVER_DOMAIN = 'dtg.threadflo.com';

    protected $_eventPrefix = 'threadflo_item';
    protected $_cacheTag = 'threadflo_item';

    protected function _construct()
    {
        $this->_init('threadflo/item');
    }

    public function loadByItemId($itemId)
    {
        if ($itemId) {
            $item = Mage::getModel('threadflo/item')->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('threadflo_item_id', $itemId)
                ->getFirstItem();

            if ($item && $item->getEntityId()) {
                return $item;
            } else {
                return Mage::getModel('threadflo/item')->setThreadfloItemId($itemId);
            }
        }

        return $this;
    }

    public function loadBySku($sku)
    {
        if ($sku) {
            $item = Mage::getModel('threadflo/item')->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('sku', $sku)
                ->getFirstItem();

            if ($item && $item->getEntityId()) {
                return $item;
            } else {
                return Mage::getModel('threadflo/item')->setSku($sku);
            }
        }

        return $this;
    }

    public function deleteImages(){
        $images = $this->getImages();

        if ($images) {
            foreach ($images as $image) {
                $image->delete();
            }
        }
    }

    public function getImages()
    {
        return Mage::getModel('threadflo/item_image')->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('threadflo_item_entity_id', $this->getId())
                ->load();
    }
    
    public function getImageUrl($pos = '')
    {
        $isSecure = Mage::app()->getStore()->isCurrentlySecure();

        if ($this->getThreadfloItemId()) {
            return 'http'.($isSecure ? 's' : '').'://'.self::THREADFLO_IMAGE_SERVER_DOMAIN.'/'.self::THREADFLO_IMAGE_DIR.$this->getThreadfloItemId().($pos ? '_'.$pos : '_1').'.png';
        }

        return '';
    }

}