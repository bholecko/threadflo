<?php

class Peakk_Threadflo_Model_Item_Image extends Mage_Core_Model_Abstract
{

    protected $_eventPrefix = 'threadflo_item_image';
    protected $_cacheTag = 'threadflo_item_image';

    protected function _construct()
    {
        $this->_init('threadflo/item_image');
    }

}