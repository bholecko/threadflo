<?php

class Peakk_Threadflo_Helper_Data extends Mage_Core_Helper_Abstract
{

    const PLATFORM_ID = 'Magento1';
    const COMPANY_ID = 'Threadflo';
    const FILE_PATH_SEPARATOR = '/';
    const DEFAULT_EXPORT_FILE_PATH = '/var/export/';
    const DEFAULT_THREADFLO_FILE_PATH = 'threadflo/';
    const DEFAULT_ORDER_EXPORT_FIELD_ID = 'entity_id';
    const TSV_FILE_NAME_PREPEND = 'threadflo_';
    const TSV_FILE_NAME_EXT = '.tsv';
    const DEFAULT_EMAIL_SENDER = 'no-reply@domain.com';
    const LOG_FILE = 'threadflo.log';
    const LOG_ERROR_FILE = 'threadflo_error.log';

    const API_ENABLED_XML_PATH = 'threadflo_general/account/api_enabled';
    const API_KEY_XML_PATH = 'threadflo_general/account/api_key';
    const MEMBER_REF_NO_XML_PATH = 'threadflo_general/account/member_ref_no';
    const EXPORT_STATUS_XML_PATH = 'threadflo_general/orders/export_status';
    const ORDER_EXPORT_ORDER_NUMBER_PREFIX_XML_PATH = 'threadflo_general/orders/order_number_prefix';
    const ORDER_EXPORT_FIELD_IDS_XML_PATH = 'threadflo_general/orders/export_field_ids';
    const EXPORT_FILE_PATH_XML_PATH = 'threadflo_general/orders/export_file_path';
    const EXPORT_EMAIL_STATUS_XML_PATH = 'threadflo_general/orders/export_email_status';
    const EXPORT_EMAIL_XML_PATH = 'threadflo_general/orders/export_email';
    const EXPORT_EMAIL_OF_SENDER_XML_PATH = 'threadflo_general/orders/export_email_of_sender';
    const EXPORT_FTP_STATUS_XML_PATH = 'threadflo_general/orders/ftp_status';
    const EXPORT_FTP_HOST_XML_PATH = 'threadflo_general/orders/ftp_host';
    const EXPORT_FTP_PORT_XML_PATH = 'threadflo_general/orders/ftp_port';
    const EXPORT_FTP_USERNAME_XML_PATH = 'threadflo_general/orders/ftp_username';
    const EXPORT_FTP_PASSWORD_XML_PATH = 'threadflo_general/orders/ftp_password';
    const EXPORT_FTP_PROTOCOL_XML_PATH = 'threadflo_general/orders/ftp_protocol';
    const EXPORT_FTP_REMOTE_PATH_XML_PATH = 'threadflo_general/orders/ftp_remote_path';

    public function isApiEnabled()
    {
        return Mage::getStoreConfigFlag(self::API_ENABLED_XML_PATH);
    }

    public function isExportEnabled()
    {
        return Mage::getStoreConfigFlag(self::EXPORT_STATUS_XML_PATH);
    }

    public function getPlatformId()
    {
        return self::PLATFORM_ID;
    }

    public function getCompanyId()
    {
        return self::COMPANY_ID;
    }

    public function getOrderNumberPrefix()
    {
        return Mage::getStoreConfig(self::ORDER_EXPORT_ORDER_NUMBER_PREFIX_XML_PATH);
    }

    public function getOrderAttributes()
    {
        $userOrderAttributes = $this->getUserOrderAttributes();
        $orderAttributes = array_unique(array_merge(array(self::DEFAULT_ORDER_EXPORT_FIELD_ID), $userOrderAttributes));

        return $orderAttributes;
    }

    public function getUserOrderAttributes()
    {
        $configValue = Mage::getStoreConfig(self::ORDER_EXPORT_FIELD_IDS_XML_PATH);

        return $configValue ? explode(',', $configValue) : array();
    }

    public function strReplaceLast($search, $replace, $str)
    {
        if(($pos = strrpos($str, $search)) !== false)
        {
            $search_length = strlen($search);
            $str = substr_replace($str, $replace, $pos, $search_length);
        }

        return $str;
    }

    public function getExportFilePath()
    {
        $configValue = Mage::getStoreConfig(self::EXPORT_FILE_PATH_XML_PATH);

        if ($configValue) {
            @mkdir(Mage::getBaseDir().self::FILE_PATH_SEPARATOR.$configValue, 0755);

            return Mage::getBaseDir().self::FILE_PATH_SEPARATOR.$configValue;
        }else {
            @mkdir(Mage::getBaseDir().self::DEFAULT_EXPORT_FILE_PATH, 0755);
            @mkdir(Mage::getBaseDir().self::DEFAULT_EXPORT_FILE_PATH.self::DEFAULT_THREADFLO_FILE_PATH, 0755);

            return Mage::getBaseDir().self::DEFAULT_EXPORT_FILE_PATH.self::DEFAULT_THREADFLO_FILE_PATH;
        }
    }

    public function isEmailExportEnabled()
    {
        $configValue = Mage::getStoreConfig(self::EXPORT_EMAIL_STATUS_XML_PATH);

        return $configValue == 1 || $configValue == '1' ? true : false;
    }

    public function getExportFileEmail()
    {
        return Mage::getStoreConfig(self::EXPORT_EMAIL_XML_PATH);
    }

    public function getExportFileEmailOfSender()
    {
        $configValue = Mage::getStoreConfig(EXPORT_EMAIL_OF_SENDER_XML_PATH);

        return $configValue ? $configValue : self::DEFAULT_EMAIL_SENDER;
    }

    public function generateUniqueFilename()
    {
        return self::TSV_FILE_NAME_PREPEND.date('Y-m-d').'_'.sprintf("%09d", rand(0, 1000000000)).self::TSV_FILE_NAME_EXT;
    }

    public function isFtpExportEnabled()
    {
        $configValue = Mage::getStoreConfig(self::EXPORT_FTP_STATUS_XML_PATH);

        return $configValue == 1 || $configValue == '1' ? true : false;
    }

    public function getFtpHost()
    {
        return Mage::getStoreConfig(self::EXPORT_FTP_HOST_XML_PATH);
    }

    public function getFtpPort($useDefault = false)
    {
        if ($useDefault) {
            return Mage::getStoreConfig(self::EXPORT_FTP_PORT_XML_PATH) ? Mage::getStoreConfig(self::EXPORT_FTP_PORT_XML_PATH) : self::EXPORT_FTP_PORT_DEFAULT;
        } else {
            return Mage::getStoreConfig(self::EXPORT_FTP_PORT_XML_PATH);
        }
    }

    public function getFtpProtocol()
    {
        return Mage::getStoreConfig(self::EXPORT_FTP_PROTOCOL_XML_PATH);
    }

    public function getFtpUsername()
    {
        return Mage::getStoreConfig(self::EXPORT_FTP_USERNAME_XML_PATH);
    }

    public function getFtpPassword()
    {
        return Mage::getStoreConfig(self::EXPORT_FTP_PASSWORD_XML_PATH);
    }

    public function getFtpRemotePath()
    {
        return Mage::getStoreConfig(self::EXPORT_FTP_REMOTE_PATH_XML_PATH);
    }

    public function getMemberRefNo()
    {
        return Mage::getStoreConfig(self::MEMBER_REF_NO_XML_PATH);
    }

    public function isApiConfigured()
    {
        $apiKey = $this->getApiKey();

        return isset($apiKey);
    }

    public function getApiKey()
    {
        return trim(Mage::getStoreConfig(self::API_KEY_XML_PATH));
    }

    public function getTodaysOrderItems()
    {
        $time = time();
        $toDate = ''.date('Y-m-d 00:00:00', $time);
        $fromDate = ''.date('Y-m-d 00:00:00', $time - (60 * 60 * 24));

        $orderItems = Mage::getModel('sales/order_item')->getCollection()
            ->addAttributeToFilter('threadflo_item_id', array('neq' => 'NULL'))
            ->addAttributeToFilter('created_at', array('from' => $fromDate, 'to' => $toDate, 'date' => true))
            ->load();

        $orderIds = array();

        if ($orderItems) {
            foreach ($orderItems as $orderItem) {
                $orderIds[] = $orderItem->getOrderId();
            }
        }

        return array_unique($orderIds);
    }

    public function getItemsArray()
    {
        $itemsArray = array();
        $items = Mage::getModel('threadflo/item')->getCollection()
            ->addFieldToFilter('threadflo_item_id', array('neq' => null))
            ->addFieldToFilter('threadflo_item_id', array('neq' => ''))
            ->load();

        if ($items) {
            foreach ($items as $item) {
                $itemsArray[] = array(
                    'entity_id' => $item->getEntityId(),
                    'threadflo_item_id' => $item->getThreadfloItemId(),
                    'graphic_description' => $item->getGraphicDescription(),
                    'image' => $item->getImageFile()
                );
            }
        }

        return $itemsArray;
    }

    public function log($message)
    {
        Mage::log($message, null, self::LOG_FILE);
    }

    public function logError($message)
    {
        Mage::log($message, null, self::LOG_ERROR_FILE);
    }

}