<?php

require_once '../../../../../../shell/abstract.php';

class Threadflo_Export_Orders extends Mage_Shell_Abstract
{

    const ORDER_ID = 1;

    public function run()
    {
        echo 'Creating import...'."\n";

        $api = Mage::getModel('threadflo/api');

        $response = $api->order(Mage::getModel('sales/order')->load(self::ORDER_ID));

        if ($response) {
            echo 'success'."\n";
        } else {
            echo 'failed'."\n";
        }

        echo 'Import complete.'."\n";
    }

}

ini_set('display_errors', 1);
ini_set('memory_limit','512M');
set_time_limit(0);

$shell = new Threadflo_Export_Orders();

$shell->run();