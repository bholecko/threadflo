<?php

require_once '../../../../../../shell/abstract.php';

class Threadflo_Export_New_Orders extends Mage_Shell_Abstract
{

    public function run()
    {
        echo 'Creating import...'."\n";

        $api = Mage::getModel('threadflo/api');

        $api->importOrderStatus();

        echo 'Import complete.'."\n";
    }

}

ini_set('display_errors', 1);
ini_set('memory_limit','512M');
set_time_limit(0);

$shell = new Threadflo_Export_New_Orders();

$shell->run();