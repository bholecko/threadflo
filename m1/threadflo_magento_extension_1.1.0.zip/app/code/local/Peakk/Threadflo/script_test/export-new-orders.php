<?php

require_once '../../../../../../shell/abstract.php';

class Threadflo_Export_New_Orders extends Mage_Shell_Abstract
{

    public function run()
    {
        echo 'Creating observer test...'."\n";

        $observer = Mage::getModel('threadflo/observer');

        $observer->checkNewOrders(null);

        echo 'Observer test complete.'."\n";
    }

}

ini_set('display_errors', 1);
ini_set('memory_limit','512M');
set_time_limit(0);

$shell = new Threadflo_Export_New_Orders();

$shell->run();