<?php

require_once '../../../../../../shell/abstract.php';

class Threadflo_Import_Colors extends Mage_Shell_Abstract
{

    public function run()
    {
        $allColors = array(
            'Aqua',

            'Asphalt',

            'Baby Blue',

            'Black',

            'Brown',

            'Cranberry',

            'Creme',

'Eggplant',

'Forest',

'Fuschia',

'Grass',

'Heather Grey',

'Kelly Green',

'Lavender',

'Lemon',

'Light Blue',

'Light Pink',

'Lime',

'Mint',

'Navy',

'New Silver',

'Olive',

'Pink',

'Purple',

'Red',

'Royal Blue',

'Seafoam',

'Slate',

'Sunshine',

'Teal',

'Turquoise',

'White',

'Black',

'White',

'Silver',

'Indigo',

'Dark Grey',

'Heather Grey',

'Warm Grey',

'Oatmeal',

'Red',

'Royal',

'Neon Green',

'Light Pink',

'Tahiti Blue',

'Navy',

'Shocking Pink',

'Turquoise',

'Hot Pink',

'Lilac',

'Purple Rush',

'Raspberry',

'Cancun',

'Light Orange',

'Light Olive',

'Mint',

'Scarlet',

'Teal',

'Plum',

'Kelly Green',

'Dark Chocolate',

'Banana Cream',

'Aqua',

'Army',

'Ash Grey Sea Foam',

'Baby Blue',

'Black',

'Brown',

'Cranberry',

'Creme',

'Eggplant',

'Forest',

'Fuchsia',

'Gold',

'Grass',

'Heather Grey',

'Kelly Green',

'Lapis',

'Lemon',

'Light Aqua',

'Light Blue',

'Light Pink',

'Lime',

'Mint',

'Navy',

'New Silver',

'Olive',

'Orange',

'Purple',

'Red',

'Royal Blue',

'Sea Foam',

'Slate',

'Sunshine',

'Teal',

'Turquoise',

'White',

'Black',

'Cardinal',

'Creme',

'Dark Chocolate',

'Heather Grey',

'Heavy Metal',

'Indigo',

'Kelly Green',

'Light Blue',

'Light Gray',

'Light Olive',

'Midnight Navy',

'Military Green',

'Natural',

'Purple Rush',

'Red',

'Royal',

'Tahiti Blue',

'Turquoise',

'Warm Gray',

'White',

'Banana Cream',

'Maroon',

'Forest Green',

'Cool Blue',

'Sand',

'Light Pink',

'Ash',

'Athletic Heather',

'Banana',

'Black',

'Brown Heather',

'Burgundy',

'Cardinal',

'Carolina Blue',

'Celadon',

'Charcoal',

'Charcoal Heather',

'Coffee',

'Cream',

'Dark Chocolate',

'Denim Heather',

'Forest Green',

'Gold',

'Harbor Blue',

'Hot Pink',

'Hunter Green',

'Kelly',

'Khaki',

'Lime',

'Military Green',

'Mustard',

'Navy',

'Orange',

'Pink',

'Powder Blue',

'Purple',

'Red',

'Royal',

'Safari Green',

'Safety Green',

'Sand',

'Silver',

'Slate',

'Tar',

'Texas Orange',

'Turquoise',

'White',

'Yellow',
);

        $allColors = array_unique($allColors);
        asort($allColors);

        echo '      $this->colors = array('."\n";

        foreach ($allColors as $color) {
            echo '          \''.str_replace(' ', '_', strtolower($color)).'\' => array(\''.$color.'\'),'."\n";
        }

        echo '      );'."\n";
    }

}

ini_set('display_errors', 1);
ini_set('memory_limit','512M');
set_time_limit(0);

$shell = new Threadflo_Import_Colors();

$shell->run();