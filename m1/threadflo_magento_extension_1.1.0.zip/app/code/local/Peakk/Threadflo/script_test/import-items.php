<?php

require_once '../../../../../../shell/abstract.php';

class Threadflo_Import_Items extends Mage_Shell_Abstract
{

    public function run()
    {
        echo 'Creating import...'."\n";

        $api = Mage::getModel('threadflo/api');

        $response = $api->importItems();

        if ($response) {
            echo 'Success.'."\n";
        } else {
            echo 'Failed.'."\n";
        }

        echo 'Import complete.'."\n";
    }

}

ini_set('display_errors', 1);
ini_set('memory_limit','512M');
set_time_limit(0);

$shell = new Threadflo_Import_Items();

$shell->run();