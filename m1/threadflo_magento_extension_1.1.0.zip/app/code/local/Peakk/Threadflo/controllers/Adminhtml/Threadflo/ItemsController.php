<?php

class Peakk_Threadflo_Adminhtml_Threadflo_ItemsController extends Mage_Adminhtml_Controller_Action
{

    public function indexAction()
    {
        $this->loadLayout()->_setActiveMenu('catalog');

        $cssBlock = $this->getLayout()->createBlock('adminhtml/template')->setTemplate('threadflo/css.phtml');
        $headerBlock = $this->getLayout()->createBlock('adminhtml/template')->setTemplate('threadflo/items/head.phtml');
        $listBlock = $this->getLayout()->createBlock('threadflo/adminhtml_items_list')->setTemplate('threadflo/items/list.phtml');

        $this->getLayout()->getBlock('content')->append($cssBlock);
        $this->getLayout()->getBlock('content')->append($headerBlock);
        $this->getLayout()->getBlock('content')->append($listBlock);

        $this->renderLayout();
    }

    public function importPostAction()
    {
        $api = Mage::getModel('threadflo/api');

        $response = $api->importItems();

        if ($response) {
            $this->_getSession()->addSuccess('Import successful.');
        } else {
            $this->_getSession()->addError('Import failed. Please check API configuration and availability. Also check script timeout server settings.');
        }

        $this->_redirect('*/*/index/', array('_secure' => true));
    }

    public function editItemAction()
    {
        $this->loadLayout()->_setActiveMenu('catalog');

        $cssBlock = $this->getLayout()->createBlock('adminhtml/template')->setTemplate('threadflo/css.phtml');
        $headerBlock = $this->getLayout()->createBlock('adminhtml/template')->setTemplate('threadflo/items/edit/head.phtml');
        $formBlock = $this->getLayout()->createBlock('threadflo/adminhtml_items_edit_form')->setTemplate('threadflo/items/edit/form.phtml');

        $this->getLayout()->getBlock('content')->append($cssBlock);
        $this->getLayout()->getBlock('content')->append($headerBlock);
        $this->getLayout()->getBlock('content')->append($formBlock);

        $this->renderLayout();
    }

    public function editItemPostAction()
    {
        $threadfloItemId = intVal($this->getRequest()->getParam('threadflo_item_id'));
        $threadfloItemSku = $this->getRequest()->getParam('threadflo_item_sku');

        if ($threadfloItemId && $threadfloItemSku) {
            $productIds = explode(',', $this->getRequest()->getParam('product_ids'));

            if (Mage::getModel('threadflo/processor')->updateThreadfloItem($productIds, $threadfloItemId, $threadfloItemSku)) {
                $this->_getSession()->addSuccess('Item/Product association updated.');
            } else {
                $this->_getSession()->addError('Unable to update item/product association using product ID '.$productIds.'.');
            }
        }

        $this->_redirect('*/*/index/', array('_secure' => true));
    }

}