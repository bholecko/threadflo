<?php

class Peakk_Threadflo_Block_Adminhtml_Items_Edit_Form extends Mage_Adminhtml_Block_Template
{

    public function getThreadfloItemId()
    {
        return $this->getRequest()->getParam('threadflo_item_id');
    }

    public function getItem()
    {
        $threadfloItemId = $this->getThreadfloItemId();

        return Mage::getModel('threadflo/item')->loadByItemId($threadfloItemId);
    }

    public function getProductIdsCsv()
    {
        return implode(',', $this->getProductIds());
    }

    public function getProductIds()
    {
        $item = $this->getItem();

        if ($item && $item->getEntityId()) {
            $threadfloItemId = $item->getThreadfloItemId();
            $products = Mage::getModel('catalog/product')->getCollection()
                ->addAttributeToFilter('threadflo_item_id', $threadfloItemId)
                ->load();

            if ($products) {
                $productIds = array();

                foreach ($products as $product) {
                    $productIds[] = $product->getId();
                }

                return $productIds;
            }
        }

        return array();
    }

}