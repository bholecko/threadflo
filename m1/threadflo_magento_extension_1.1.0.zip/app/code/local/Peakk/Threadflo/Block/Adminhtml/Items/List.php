<?php

class Peakk_Threadflo_Block_Adminhtml_Items_List extends Mage_Adminhtml_Block_Template
{

    public function getProductsWithItemId()
    {
        return Mage::getModel('catalog/product')->getCollection()
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('threadflo_item_id')
            ->addAttributeToFilter('threadflo_item_id', array('neq' => null))
            ->addAttributeToFilter('threadflo_item_id', array('neq' => ''))
            ->load();
    }
    
    public function getItems()
    {
        return Mage::getModel('threadflo/item')->getCollection()
            ->addFieldToFilter('threadflo_item_id', array('neq' => null))
            ->addFieldToFilter('threadflo_item_id', array('neq' => ''))
            ->load();
    }

}